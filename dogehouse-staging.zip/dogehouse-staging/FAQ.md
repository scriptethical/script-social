# FAQ

## Why did you choose Elixir?

It's fun to program in. The error messages are awful and there's no static typing, but other than that it's great.

## How will DogeHouse make money?

- DogeNitro
- DogeSubscriptions
- DogeAds

## Will open source contributors get paid?

After DogeHouse adds monetization and it makes enough to pay server costs, there will be bounties.

## How will you market this?

Once the core product is solid, I will be doing events with the community and other influencers.

## Are you working on this full-time?

yes

## Discord Stages?

https://www.youtube.com/watch?v=FmAL5qvJkaI

## Are you ever doing video?

Not for a long time, maybe never.
