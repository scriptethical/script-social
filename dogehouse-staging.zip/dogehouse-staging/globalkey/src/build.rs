fn main() {
    node_bindgen::build::configure();
}
