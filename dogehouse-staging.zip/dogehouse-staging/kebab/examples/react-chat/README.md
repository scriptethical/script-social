# Text-only chat (an example app)

1. Build the API package: `$ yarn` and `$ yarn build` in kebab's root directory
2. Setup the example: `$ yarn`
3. `$ yarn start` (put `SKIP_PREFLIGHT_CHECK=true` in your .env if it crashes)
