# Audio-only client (an example app)

1. Put your access- and refresh-token in `.env` (`DOGEHOUSE_TOKEN`, `DOGEHOUSE_REFRESH_TOKEN`)
2. Build the API package: `$ yarn` and `$ yarn build` in kebab's root directory
3. Setup the example: `$ yarn`
4. `$ yarn start`
