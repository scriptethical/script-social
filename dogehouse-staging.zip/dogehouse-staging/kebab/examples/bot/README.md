# An example bot

1. Put your bot's api key in `.env` as `DOGEHOUSE_API_KEY`
2. Build the API package: `$ yarn` and `$ yarn build` in kebab's root directory
3. Build the example: `$ yarn` and `$ yarn build`
4. `$ yarn start`
