import React from "react";

interface FieldSpacerProps {}

export const FieldSpacer: React.FC<FieldSpacerProps> = ({}) => {
  return <div className={`flex my-6`} />;
};
