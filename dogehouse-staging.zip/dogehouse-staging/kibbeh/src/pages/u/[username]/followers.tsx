import { FollowingPage } from "../../../modules/user/FollowingPage";

export default FollowingPage;
