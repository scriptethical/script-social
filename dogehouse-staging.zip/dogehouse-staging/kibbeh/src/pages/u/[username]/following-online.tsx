import { FollowingOnlinePage } from "../../../modules/user/FollowingOnlinePage";

export default FollowingOnlinePage;
