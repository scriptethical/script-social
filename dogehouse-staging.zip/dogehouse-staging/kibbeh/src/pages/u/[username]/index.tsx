import { UserPage } from "../../../modules/user/UserPage";

export default UserPage;
