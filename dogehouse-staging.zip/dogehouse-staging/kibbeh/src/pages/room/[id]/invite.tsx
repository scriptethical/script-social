import { InviteRoomPage } from "../../../modules/room/InviteRoomPage";

export default InviteRoomPage;
