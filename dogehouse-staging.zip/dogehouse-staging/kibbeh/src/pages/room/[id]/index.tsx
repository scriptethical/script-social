import { RoomPage } from "../../../modules/room/RoomPage";

export default RoomPage;
