import { BotsPage } from "../../../modules/developer/BotsPage";

export default BotsPage;
