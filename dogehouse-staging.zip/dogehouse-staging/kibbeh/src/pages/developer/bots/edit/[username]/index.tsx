import { BotsEditPage } from "../../../../../modules/developer/BotsEditPage";

export default BotsEditPage;
