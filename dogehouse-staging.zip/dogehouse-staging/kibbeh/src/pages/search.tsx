import { SearchPage } from "../modules/search/SearchPage";

export default SearchPage;
