import { LoginPage } from "../modules/landing-page/LoginPage";
//
export default LoginPage;
