import { LanguagePage } from "../modules/language/LanguagePage";

export default LanguagePage;
