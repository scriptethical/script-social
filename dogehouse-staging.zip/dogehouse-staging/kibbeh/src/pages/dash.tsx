import { DashboardPage } from "../modules/dashboard/DashboardPage";

export default DashboardPage;
