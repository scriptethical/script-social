import { OverlaySettingsPage } from "../modules/settings/OverlaySettingsPage";

export default OverlaySettingsPage;
