import { ViewScheduledRoomPage } from "../../modules/room/ViewScheduledRoomPage";

export default ViewScheduledRoomPage;
