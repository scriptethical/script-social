import { SoundEffectSettings } from "../modules/settings/SoundEffectSettingsPage";

export default SoundEffectSettings;
