import { PrivacySettingsPage } from "../modules/settings/PrivacySettingsPage";

export default PrivacySettingsPage;
