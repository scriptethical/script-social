import { AdminPage } from "../modules/admin/AdminPage";

export default AdminPage;
