export interface Bot {
  id: string;
  username: string;
  avatarUrl: string;
  displayName: string;
  apiKey: string;
}
