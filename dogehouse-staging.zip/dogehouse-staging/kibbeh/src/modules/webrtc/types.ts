export type AddWsListenerOnce = (op: string, fn: (d: any) => void) => void;
