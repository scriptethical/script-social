export const defaultTestUsername = "cypress_user";
export const defaultRoomName = "DogeHouse Acquisition Discussion";
export const defaultAvatarUrl =
  "https://pbs.twimg.com/profile_images/1152793238761345024/VRBvxeCM_400x400.jpg";
export const defaultBannerUrl = "https://pbs.twimg.com/profile_banners/840626569743912960/1601562221/600x200";
export const defaultBio = "I am a good description, I promise.";
