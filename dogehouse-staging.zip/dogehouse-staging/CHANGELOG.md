# Changelog

## 4/16/2021

- Switched to a new UI

## 2/20/2021

- Added changelog
