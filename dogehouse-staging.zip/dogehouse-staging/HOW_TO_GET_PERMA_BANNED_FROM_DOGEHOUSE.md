# Things that will get you perma banned

0. Spam creating a ton of scheduled rooms
1. NSFW profile/banner image
2. Ban evading rooms
 - if you get banned from a room, don't create another DogeHouse account and join the same room
