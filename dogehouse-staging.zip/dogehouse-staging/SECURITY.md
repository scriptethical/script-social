# Security Policy

## Reporting a Vulnerability

DM me on https://twitter.com/benawad or https://discord.gg/wCbKBZF9cV
